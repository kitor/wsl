PulseAudio 6.0 for Windows
ZIP distribution by Kajetan Krykwinski - http://kitor.pl
based on RPM packages by mikedep333
Source: https://build.opensuse.org/package/binary/home:mikedep333:branches:home:mkbosmans:mingw32:pulseaudio/mingw32-pulseaudio6?arch=x86_64&filename=mingw32-pulseaudio-6.0-11.64.noarch.rpm&repository=openSUSE_13.2